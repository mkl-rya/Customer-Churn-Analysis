use northwind;
select * from customers limit 5;
select * from employees limit 5;

#1 problem statement -  Analyze Order Frequency for Each Customer

WITH order_frequency AS (SELECT customer_id,order_date,
LAG(order_date) OVER (PARTITION BY customer_id ORDER BY order_date) AS prev_order_date,
DATEDIFF(order_date, LAG(order_date) OVER (PARTITION BY customer_id ORDER BY order_date)) AS time_gap
FROM orders)

#2 problem statement -  Calculate Average Time Between Orders for Customer Segments

SELECT  customer_id,AVG(time_gap) AS average_time_gap
FROM order_frequency
GROUP BY customer_id
ORDER BY average_time_gap DESC;

WITH order_frequency AS (
SELECT customer_id,order_date,
LAG(order_date) OVER (PARTITION BY customer_id ORDER BY order_date) AS prev_order_date,
DATEDIFF(order_date, LAG(order_date) OVER (PARTITION BY customer_id ORDER BY order_date)) AS time_gap
FROM orders),

 customer_segment as (SELECT customer_id,
    CASE WHEN AVG(time_gap) <= 30 THEN "frequent buyer"
         WHEN AVG(time_gap) <= 90 THEN "regular buyer"
        ELSE "infrequent buyer" 
END AS segment FROM  order_frequency
GROUP BY customer_id)

select segment,avg(time_gap) as average_time_gap from order_frequency o
join customer_segment cs on o.customer_id = cs.customer_id
group by segment;


#3 problem statement - Analyze Average Order Value (AOV) for Churning and Non-Churning Customers

WITH churn_status AS (SELECT c.id, 
	CASE
	WHEN o.customer_id IS NOT NULL THEN 'non churning'
	ELSE 'churning'
	END AS churn_status
    FROM customers c
    LEFT JOIN orders o ON c.id = o.customer_id),

order_value AS (SELECT o.customer_id,SUM(od.quantity * od.unit_price) AS order_value 
    FROM orders o
    JOIN order_details od ON o.id = od.order_id  -- Corrected join condition
    GROUP BY o.customer_id) -- Grouping by customer_id to aggregate the order values

SELECT cs.churn_status,AVG(ov.order_value) AS avg_order_value
FROM churn_status cs 
JOIN order_value ov ON cs.id = ov.customer_id
GROUP BY cs.churn_status;

#4 problem statement - Classify Customers Based on Total Order Value and Count Customers in Each Category

with order_value_distribution as (Select c.id,sum(od.quantity*od.unit_price) as order_value from customers c 
left join orders o on c.id=o.customer_id
left join order_details od on o.id = od.order_id
group by c.id)

select case 
when order_value <= 1000 then  "low order value"
when order_value <= 5000 then  "meduim order value"
else "High order value"

end as order_value_category,count(id) as customer_count--
from order_value_distribution 
group by order_value_category;

#5 problem statement - Analyzing Shifts in Product Preferences Among Churned Customers

SELECT DISTINCT c.id AS customer_id,c.company AS customer_name,p.category AS churned_category,
    CASE 
	WHEN o.id IS NULL THEN 'churned' 
	ELSE 'active' 
    END AS churned_status 
FROM customers c  -- Assuming 'customers' is the correct table name
LEFT JOIN orders o ON c.id = o.customer_id
LEFT JOIN order_details od ON o.id = od.order_id  -- Ensure 'order_details' is properly joined
LEFT JOIN products p ON od.product_id = p.id
WHERE c.id IN (SELECT customer_id FROM orders WHERE status_id = 3)  -- Churned customers
    
AND (p.category IS NULL OR p.category NOT IN (  -- Handle NULL categories
	SELECT DISTINCT p.category 
	FROM customers c2  -- Use a different alias to avoid confusion
	LEFT JOIN orders o2 ON c2.id = o2.customer_id
	LEFT JOIN order_details od2 ON o2.id = od2.order_id   
	LEFT JOIN products p2 ON od2.product_id = p2.id
	WHERE c2.id NOT IN (SELECT customer_id FROM orders 
                WHERE status_id = 3)));

#6 problem statement - Analyse most frequent purchased category before and after churn? did customer started purchasing product from diff. product line?

with churned_customer as (select distinct customer_id from orders 
    where status_id = 3)
select p.category,
count(case when o.customer_id in (select customer_id from churned_customer) then o.id end) as churned_count,
count(case when o.customer_id not in (select customer_id from churned_customer) then o.id end) as active_count
from orders o 
join order_details od on o.id = od.order_id
join products p on p.id = od.product_id
group by p.category 
order by churned_count desc;

## another way 

with churned_customer as (select distinct customer_id from orders 
    where status_id = 3),
churned_category_count as (select p.category, count(*) as churned_count 
    from orders o  
    join order_details od on o.id = od.order_id
    join products p on p.id = od.product_id
    where o.customer_id in (select customer_id from churned_customer)
    group by p.category),
active_category_count as (select p.category, count(*) as active_count 
    from orders o  
    join order_details od on o.id = od.order_id
    join products p on p.id = od.product_id
    where o.customer_id not in (select customer_id from churned_customer)
    group by p.category )

select cc.category,cc.churned_count,ac.active_count
from churned_category_count cc 
join active_category_count ac on cc.category = ac.category 
order by cc.churned_count desc, ac.active_count desc;


#7 Problem Statement - investigate churn rate by region understand location customer purchase behaviour to that location
-- customer data analysis based on thier geographical location
-- find out customer order shipping status --> churning customer

WITH churned_customer AS (SELECT DISTINCT customer_id FROM orders
WHERE status_id IN (SELECT id FROM orders_status
 WHERE status_name = 'Closed' OR status_name = 'Shipped')),
customer_locations AS (SELECT c.id,c.company,c.city,c.state_province,c.country_region,
	CASE
	WHEN cc.customer_id = c.id THEN 'Churned' ELSE 'Active'
	END AS customer_status FROM customers c
    LEFT JOIN churned_customer cc ON c.id = cc.customer_id)
SELECT country_region,state_province,city,
    COUNT(CASE WHEN customer_status = 'Churned' THEN 1 END) AS churned_count,
    COUNT(CASE WHEN customer_status = 'Active' THEN 1 END) AS active_count,
    ROUND((COUNT(CASE WHEN customer_status = 'Churned' THEN 1 END) * 100.0) / COUNT(*), 2) AS churn_rate
FROM customer_locations
GROUP BY country_region, state_province, city
ORDER BY churn_rate DESC;


#8 problem statement - Retrive total number of order,revenue,quantity for each region
-- analysis pattern 

select c.country_region,c.state_province,c.city,
count(o.id)as total_orders,
round(sum(od.quantity), 2) as total_quantity,
round(sum(od.quantity * od.unit_price), 2) as total_revenue
from customers c

join orders o on c.id= o.customer_id
join order_details od on o.id= od.order_id
group by c.country_region, c.state_province, c.city
order by total_orders desc;

#9 problem statement - assign "risk - score" each customer purchased frequency , purchased frequency declined  order value for same specific category 

SELECT c.id AS customer_id,c.company AS company_name,
COUNT(o.id) AS total_orders,
SUM(od.quantity * od.unit_price) AS total_spent,
    CASE
        WHEN COUNT(o.id) >= 7 AND SUM(od.quantity * od.unit_price) >= 1000 THEN 'Low Risk'
        WHEN COUNT(o.id) BETWEEN 4 AND 7 AND SUM(od.quantity * od.unit_price) BETWEEN 500 AND 999 THEN 'Medium Risk'
        ELSE 'High Risk'
    END AS risk_category
FROM customers c
LEFT JOIN orders o ON c.id = o.customer_id
LEFT JOIN order_details od ON o.id = od.order_id
GROUP BY c.id, c.company
ORDER BY total_orders DESC, total_spent DESC;

#10 problem statement - customer life time value to priortize retention effects

SELECT c.id AS customer_id,c.company,COUNT(DISTINCT o.id) AS total_orders_last_6_months
FROM customers c
LEFT JOIN orders o ON c.id = o.customer_id
WHERE o.order_date >= DATE_SUB((SELECT MAX(order_date) FROM orders), INTERVAL 6 MONTH)
GROUP BY c.id, c.company
HAVING COUNT(DISTINCT o.id) < (SELECT AVG(order_count)
        FROM (SELECT c.id AS customer_id, COUNT(DISTINCT o.id) AS order_count
            FROM customers c JOIN orders o ON c.id = o.customer_id
            WHERE o.order_date >= DATE_SUB((SELECT MAX(order_date) FROM orders), INTERVAL 6 MONTH)
            GROUP BY c.id) AS order_counts);

#11 "What is the Customer Lifetime Value (CLTV) for each customer?"
SELECT c.id AS customer_id,
    ROUND(SUM(od.quantity * od.unit_price * (1 - od.discount)) - SUM(o.shipping_fee + o.taxes), 2) AS cltv
FROM customers c
JOIN orders o ON c.id = o.customer_id
JOIN order_details od ON o.id = od.order_id
GROUP BY c.id;